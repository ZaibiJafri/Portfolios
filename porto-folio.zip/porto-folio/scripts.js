window.addEventListener('load', function() {
    document.querySelector('.about-me').classList.add('loaded');
  });
  function toggleMenu() {
    const navBar = document.querySelector('.nav-bar ul');
    navBar.classList.toggle('show');
  }
  